<?php include 'inc/header.php'; ?>



<div class="container my-5">

    <div class="row">
        




    <div class="col-lg-4 mb-3">



            <div class="card">
            <img src="images/one.jpg" class="card-img-top">
            <div class="card-body">
            <h5 class="card-title">product 1</h5>
            <p class="text-muted">2000 EGP</p>
            <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            <a href="show.php" class="btn btn-primary">Show</a>

            <a href="edit.php" class="btn btn-info">Edit</a>
            <a href="" class="btn btn-danger">Delete</a>

            </div>
        </div>
        
    </div>

    <div class="col-lg-4 mb-3">



            <div class="card">
            <img src="images/two.jpg" class="card-img-top">
            <div class="card-body">
            <h5 class="card-title">product 2</h5>
            <p class="text-muted">2000 EGP</p>
            <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            <a href="show.php" class="btn btn-primary">Show</a>

            <a href="edit.php" class="btn btn-info">Edit</a>
            <a href="" class="btn btn-danger">Delete</a>

            </div>
        </div>
        
    </div>

    <div class="col-lg-4 mb-3">



            <div class="card">
            <img src="images/three.jpg" class="card-img-top">
            <div class="card-body">
            <h5 class="card-title">product 3</h5>
            <p class="text-muted">2000 EGP</p>
            <p class="card-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
            <a href="show.php" class="btn btn-primary">Show</a>

            <a href="edit.php" class="btn btn-info">Edit</a>
            <a href="" class="btn btn-danger">Delete</a>

            </div>
        </div>
        
    </div>
    
        
    </div>

</div>



<?php include 'inc/footer.php'; ?>